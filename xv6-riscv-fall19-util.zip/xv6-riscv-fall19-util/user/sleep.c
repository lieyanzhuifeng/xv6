#include "kernel/types.h"  
#include "user/user.h"     

const int duration_pos = 1;   // 参数位置，argv[1] 是 sleep 时间
typedef enum {wrong_char, success_parse, toomany_char} cmd_parse;

cmd_parse parse_cmd(int argc, char** argv);

int 
main(int argc, char** argv){
    if(argc == 1){   // 没有参数
        printf("Please enter the parameters!\n");
        exit();
    } else {
        cmd_parse parse_result = parse_cmd(argc, argv);
        if(parse_result == toomany_char){
            printf("Too many args!\n");
            exit();
        } else if(parse_result == wrong_char){
            printf("Cannot input alphabet, number only\n");
            exit();
        } else {
            int duration = atoi(argv[duration_pos]);  // 转换成整数
            sleep(duration);                          // 调用系统调用挂起
            exit();
        }
    }
}

cmd_parse
parse_cmd(int argc, char** argv){
    if(argc > 2) return toomany_char;   // 参数太多

    // 检查是否都是数字
    for(int i = 0; argv[duration_pos][i] != '\0'; i++){
        if(argv[duration_pos][i] < '0' || argv[duration_pos][i] > '9')
            return wrong_char;
    }
    return success_parse;
}
