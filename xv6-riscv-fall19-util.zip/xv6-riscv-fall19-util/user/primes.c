// user/primes.c
#include "kernel/types.h"
#include "user/user.h"

void sieve(int p0)
{
  int p;
  if (read(p0, &p, sizeof(p)) != sizeof(p)) {
    close(p0);
    exit();  // ✅ 没参数
  }

  printf("prime %d\n", p);

  int p1[2];
  pipe(p1);

  int pid = fork();
  if (pid == 0) {
    // 子进程
    close(p1[1]); // 关闭写端
    sieve(p1[0]);
  } else {
    // 父进程
    close(p1[0]); // 关闭读端
    int num;
    while (read(p0, &num, sizeof(num)) == sizeof(num)) {
      if (num % p != 0) {
        write(p1[1], &num, sizeof(num));
      }
    }
    close(p0);
    close(p1[1]);
    wait();  
    exit();    
  }
}

int main(int argc, char *argv[])
{
  int p0[2];
  pipe(p0);

  int pid = fork();
  if (pid == 0) {
    close(p0[1]);
    sieve(p0[0]);
    exit();   // 子进程调用 exit
  } else {
    close(p0[0]);
    for (int i = 2; i <= 35; i++) {
      write(p0[1], &i, sizeof(i));
    }
    close(p0[1]);
    wait();
    exit();   // 父进程调用 exit
  }

  // 这一句其实永远不会执行，但为了防止编译器警告可以写：
  return 0;
}

